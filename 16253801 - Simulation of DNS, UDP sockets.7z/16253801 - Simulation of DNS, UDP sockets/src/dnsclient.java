//UDP DNS Client –
import java.io. * ;
import java.net. * ;
import java.util.Arrays;

public class dnsclient {
    public static void main(String args[]) throws IOException {
        BufferedReader br = new BufferedReader(new
                InputStreamReader(System. in ));
//        DatagramSocket clientsocket = new DatagramSocket();
        InetAddress ipaddress;
        if (args.length == 0) ipaddress = InetAddress.getLocalHost();
        else ipaddress = InetAddress.getByName(args[0]);
        byte[] senddata = new byte[1024];
//        int portaddr = 1361;
        System.out.print("pau.edu.tr, google.com, gmail.com, facebook.com\n");
        System.out.print("Enter the hostname : ");
        String sentence = br.readLine();
        System.out.println();
        senddata = sentence.getBytes();
//        DatagramPacket pack = new DatagramPacket(senddata, senddata.length, ipaddress, portaddr);
        DatagramPacket pack_1,pack_2,pack_3,pack_4;
        for (int port = 1024; port <= 2000; port++) {
            try {
                // the next line will fail and drop into the catch block if
                // there is already a server running on port i
                DatagramSocket server = new DatagramSocket(port);
                server.close();
            }
            catch(SocketException ex) {
                if (port == 1361){
                    pack_1 = new DatagramPacket(senddata, senddata.length, ipaddress, 1361);
                    receivedata(pack_1);
                }
                if (port == 1362){
                    pack_2 = new DatagramPacket(senddata, senddata.length, ipaddress, 1362);
                    receivedata(pack_2);
                }
                if (port == 1363){
                    pack_3 = new DatagramPacket(senddata, senddata.length, ipaddress, 1363);
                    receivedata(pack_3);
                }
                if (port == 1364){
                    pack_4 = new DatagramPacket(senddata, senddata.length, ipaddress, 1364);
                    receivedata(pack_4);
                }

            }
        }
    }
    static void receivedata(DatagramPacket pack) throws IOException {
        DatagramSocket clientsocket = new DatagramSocket();
        byte[] receivedata = new byte[1024];
        try {
            clientsocket.send(pack);
            // send packets...
        }
        catch (SocketException ex) {
            System.err.println(ex);
        }
        DatagramPacket recvpack = new
                DatagramPacket(receivedata, receivedata.length);
        clientsocket.receive(recvpack);
        String modified = new String(recvpack.getData());
        modified = modified.trim();
        System.out.println("IP Address: " + modified);
        System.out.println(Arrays.toString(new SocketAddress[]{pack.getSocketAddress()}) + "\n");
        clientsocket.close();
    }
}